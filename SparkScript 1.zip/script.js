import { parse } from './parser.js';

document.addEventListener('DOMContentLoaded', () => {
  const codeEditor = document.getElementById('codeEditor');
  const runButton = document.getElementById('runButton');
  const clearButton = document.getElementById('clearButton');
  const outputDiv = document.getElementById('output');
  const helpButton = document.getElementById('helpButton');
  const fullscreenButton = document.getElementById('fullscreenButton');
  const downloadButton = document.getElementById('downloadButton');
  const loadButton = document.getElementById('loadButton');
  const fileInput = document.getElementById('fileInput');
  const outputContainer = document.getElementById('output-container');

  const runSparkScript = (code) => {
    try {
      const result = parse(code);
      outputDiv.innerHTML = result;
    } catch (error) {
      outputDiv.textContent = `Error: ${error.message}`;
    }
  };

  runButton.addEventListener('click', () => {
    const code = codeEditor.value;
    runSparkScript(code);
  });

  clearButton.addEventListener('click', () => {
    codeEditor.value = '';
    outputDiv.textContent = '';
  });

  helpButton.addEventListener('click', () => {
    codeEditor.value = `// SparkScript Help\n\n// SparkScript follows the P.R.O.G.R.A.M. principle:\n// Programming in SparkScript Requires Our code to Generate Resources to Advance the features for Making programs and applications.\n\n// Basics:\n// 1. All programs start with [start].\n// 2. Variables are declared using <[variable_name]> = [value].\n// 3. Databases are created using [database_name] = create database, tables created by <[database_name]>.table_name = create table, columns by <[database_name]>.table_name.column_name = add column [type]\n// 4. Insert into tables by <[database_name]>.table_name.insert = <[value] into [column]>\n// 5. Operations use <[value] + [value]> or <[variable] > [variable]>\n// 6. Output is done by print: <[variable]> or print: <[operation]>\n// 7. Change the background color with color = <color_name>\n// 8. Create interactive buttons with create button: <button_text>, action: <sparkscript_code>\n\n\n// Example Code:\n[start]\ncolor = steelblue\n[my_db] = create database\n<[my_db]>.my_table = create table\n<[my_db]>.my_table.my_column = add column integer\n<[my_db]>.my_table.insert = <5 into my_column>\n\n<var_a> = 10\n<var_b> = 20\n<var_c> = <[var_a] + [var_b]>\nprint: <[var_c]>\n\ncreate button: Click Me, action: print: <"Button Clicked!">`;
  });

  fullscreenButton.addEventListener('click', () => {
    if (!document.fullscreenElement) {
      if (outputContainer.requestFullscreen) {
        outputContainer.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  });

  downloadButton.addEventListener('click', () => {
    const code = codeEditor.value;
    const blob = new Blob([code], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sparkscript.ss1';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  });

  loadButton.addEventListener('click', () => {
    fileInput.click();
  });

  fileInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        codeEditor.value = e.target.result;
      };
      reader.readAsText(file);
    }
  });

  outputDiv.addEventListener('click', (event) => {
    if (event.target.tagName === 'BUTTON' && event.target.dataset.sparkAction) {
      runSparkScript(event.target.dataset.sparkAction);
    }
  });

  // Handle fullscreen change
  document.addEventListener('fullscreenchange', () => {
    fullscreenButton.textContent = document.fullscreenElement ? 'Exit Fullscreen' : 'Fullscreen';
  });
});