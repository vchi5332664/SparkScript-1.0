const variables = {};
const databases = {};

/**
 * Evaluates a mathematical or comparison operation.
 * @param {number|boolean} left - The left operand.
 * @param {string} op - The operator (+, -, ×, ÷, <, >, =).
 * @param {number|boolean} right - The right operand.
 * @returns {number|boolean} The result of the operation.
 * @throws {Error} If the operation is unknown or division by zero occurs.
 */
function evaluateOperation(left, op, right) {
  if (typeof left === 'undefined' || typeof right === 'undefined') {
    throw new Error(`Cannot perform '${op}' operation on undefined value`);
  }
  
  // Convert string numbers to actual numbers
  if (typeof left === 'string' && !isNaN(Number(left))) {
    left = Number(left);
  }
  if (typeof right === 'string' && !isNaN(Number(right))) {
    right = Number(right);
  }
  
  switch (op) {
    case '+': 
      // Handle both number addition and string concatenation
      return left + right;
    case '-': return Number(left) - Number(right);
    case '×': return Number(left) * Number(right);
    case '÷':
      if (Number(right) === 0) {
        throw new Error("Cannot divide by zero");
      }
      return Number(left) / Number(right);
    case '<': return Number(left) < Number(right);
    case '>': return Number(left) > Number(right);
    case '=': return left === right;
    default: throw new Error(`Unknown operation: ${op}`);
  }
}

/**
 * Resolves the value of a variable or a literal.
 * If the value is an expression, it evaluates the expression.
 * @param {string} value - The value to resolve.
 * @returns {number|string|boolean} The resolved value.
 * @throws {Error} If the variable is not defined or the expression is invalid.
 */
function resolveValue(value) {
  if (typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }
  if (value.startsWith('<') && value.endsWith('>')) {
    const expression = value.slice(1, -1).trim();
    if (expression.includes('+') || expression.includes('-') || expression.includes('×') || expression.includes('÷') || expression.includes('<') || expression.includes('>') || expression.includes('=')) {
      return evaluateExpression(expression);
    }

    const variableName = expression.trim();
    if (variables.hasOwnProperty(variableName)) {
      return variables[variableName];
    }
    throw new Error(`Variable ${variableName} is not defined`);
  }

  if (!isNaN(Number(value))) {
    return Number(value);
  }

  return value;
}

/**
 * Evaluates an expression with two operands and an operator.
 * @param {string} expression - The expression to evaluate.
 * @returns {number|boolean} The result of the expression.
 * @throws {Error} If the expression is invalid.
 */
function evaluateExpression(expression) {
  const match = expression.match(/^(.+?)\s*([+\-×÷<>])\s*(.+?)$/);
  if (!match) {
    throw new Error(`Invalid expression: ${expression}`);
  }
  const left = resolveValue(match[1].trim());
  const op = match[2].trim();
  const right = resolveValue(match[3].trim());
  return evaluateOperation(left, op, right);
}

/**
 * Handles database related commands: create database, create table, add column, insert.
 * @param {string} command - The full database command.
 * @param {string} remaining - The part of the command after the database path.
 * @returns {string} A message indicating the result of the database command.
 * @throws {Error} If the database command is invalid or if a database/table/column already exists.
 */
function handleDatabaseCommand(command, remaining) {
  const match = command.match(/^(.*)\s*=\s*(create database|create table|add column|insert)/);

  if (!match) {
    throw new Error(`Invalid database command: ${command}`);
  }

  const databasePath = match[1].trim();
  const action = match[2].trim();
  const pathParts = databasePath.split('.').map(part => part.trim());

  if (action === 'create database') {
    if (pathParts.length !== 1) {
      throw new Error("Invalid database creation command: " + databasePath);
    }
    const dbName = pathParts[0];
    if (databases.hasOwnProperty(dbName)) {
      throw new Error(`Database ${dbName} already exists`);
    }
    databases[dbName] = {};
    return `<span class="database">Database ${dbName} created.</span>`;
  }

  if (pathParts.length < 2) {
    throw new Error('Invalid database access path, expecting database.table structure');
  }

  const dbName = pathParts[0];
  const tableName = pathParts[1];
  if (!databases[dbName]) {
    throw new Error(`Database ${dbName} does not exist`);
  }

  const table = databases[dbName];

  if (action === 'create table') {
    if (pathParts.length !== 2) {
      throw new Error(`Invalid table creation command: ${databasePath}`);
    }

    if (table.hasOwnProperty(tableName)) {
      throw new Error(`Table ${tableName} already exists in database ${dbName}`);
    }
    table[tableName] = { columns: {}, rows: [] };
    return `<span class="database">Table ${tableName} created in database ${dbName}</span>`;
  }

  if (!table[tableName]) {
    throw new Error(`Table ${tableName} not found in database ${dbName}`);
  }

  if (action === 'add column') {
    if (pathParts.length !== 3) {
      throw new Error(`Invalid add column command: ${databasePath}`);
    }
    const columnName = pathParts[2];
    const columnTypeMatch = remaining.trim().match(/^([a-zA-Z]+)$/);
    if (!columnTypeMatch) {
      throw new Error(`Invalid column type: ${remaining}`);
    }
    const columnType = columnTypeMatch[1];

    if (table[tableName].columns.hasOwnProperty(columnName)) {
      throw new Error(`Column ${columnName} already exists in table ${tableName}`);
    }
    table[tableName].columns[columnName] = columnType;
    return `<span class="database">Column ${columnName} added to table ${tableName} as type ${columnType}</span>`;
  }

  if (action === 'insert') {
    const insertMatch = remaining.match(/^<\s*(.+?)\s+into\s+(.+?)\s*>$/);
    if (!insertMatch) {
      throw new Error(`Invalid insert command: ${remaining}`);
    }

    const valueToInsert = resolveValue(insertMatch[1].trim());
    const targetColumn = insertMatch[2].trim();

    if (!table[tableName].columns[targetColumn]) {
      throw new Error(`Column ${targetColumn} not found in table ${tableName}`);
    }

    if (table[tableName].columns[targetColumn] === 'integer') {
      if (isNaN(Number(valueToInsert))) {
        throw new Error(`Value ${valueToInsert} is not an integer`);
      }
      table[tableName].rows.push({ [targetColumn]: Number(valueToInsert) });
    } else {
      table[tableName].rows.push({ [targetColumn]: valueToInsert });
    }

    return `<span class="database">Inserted value ${valueToInsert} into column ${targetColumn} of table ${tableName}</span>`;
  }

  throw new Error(`Unknown database action ${action}`);
}

/**
 * Parses and executes SparkScript code line by line.
 * @param {string} code - The SparkScript code to parse.
 * @returns {string} The output generated by the code.
 */
function parse(code) {
  // Reset variables for each new execution
  Object.keys(variables).forEach(key => delete variables[key]);
  Object.keys(databases).forEach(key => delete databases[key]);
  
  const lines = code.split('\n').filter(line => line.trim() && !line.trim().startsWith('//'));
  let output = '';
  let hasStart = false;

  // Check for [start] directive
  if (!lines.some(line => line.trim().startsWith('[start]'))) {
    throw new Error('Program must begin with [start]');
  }

  for (const line of lines) {
    try {
      const trimmedLine = line.trim();
      let lineOutput = "";

      if (trimmedLine.startsWith('[start]')) {
        if (hasStart) {
          throw new Error('Multiple [start] declarations found');
        }
        hasStart = true;
        lineOutput += `<span class="start">Program started ✓</span>`;
      }
      else if (!hasStart) {
        continue; // Skip lines before [start]
      }
      else if (trimmedLine.startsWith('color =')) {
        const colorValue = trimmedLine.substring(7).trim();
        document.body.style.backgroundColor = colorValue;
        lineOutput += `<span class="operation">Background color set to ${colorValue}</span>`;
      }
      else if (trimmedLine.startsWith('create button:')) {
        const buttonMatch = trimmedLine.match(/^create button:\s*([^,]+?),\s*action:\s*(.+)$/);
        if (buttonMatch) {
          const buttonText = buttonMatch[1].trim();
          const buttonAction = buttonMatch[2].trim();
          lineOutput += `<button data-spark-action="${buttonAction.replace(/"/g, '&quot;')}">${buttonText}</button>`;
        } else {
          throw new Error(`Invalid button creation command: ${trimmedLine}`);
        }
      }
      else if (trimmedLine.startsWith('<') && trimmedLine.includes('=')) {
        const varMatch = trimmedLine.match(/^<([a-zA-Z0-9_]+)>\s*=\s*(.+)$/);
        if (!varMatch) {
          throw new Error(`Invalid variable assignment: ${trimmedLine}`);
        }
        const varName = varMatch[1].trim();
        const varValue = varMatch[2].trim();

        variables[varName] = resolveValue(varValue);
        lineOutput += `<span class="variable">✓ ${varName} = ${variables[varName]}</span>`;
      }
      else if (trimmedLine.startsWith('print:')) {
        const printMatch = trimmedLine.match(/^print:\s*(.+)$/);
        if (!printMatch) {
          throw new Error(`Invalid print command ${trimmedLine}`);
        }
        const valueToPrint = resolveValue(printMatch[1].trim());
        lineOutput += `Output → ${valueToPrint}`;
      }
      else if (trimmedLine.includes('create database') || trimmedLine.includes('create table') || trimmedLine.includes('add column') || trimmedLine.includes('insert')) {
        lineOutput += handleDatabaseCommand(trimmedLine, trimmedLine.substring(trimmedLine.indexOf('=') + 1));
      }
      else {
        throw new Error(`Unrecognized command: ${trimmedLine}`);
      }
      output += lineOutput + '\n';
    } catch (error) {
      output += `<span style="color: #ff4444">Error: ${error.message}</span>\n`;
    }
  }

  return output;
}

export { parse };